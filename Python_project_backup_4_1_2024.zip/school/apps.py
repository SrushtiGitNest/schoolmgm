from django.apps import AppConfig

class SchoolConfig(AppConfig):
    name = 'school'